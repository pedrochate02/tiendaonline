package tiendaonline2;

import java.util.List;
import java.util.Scanner;

/**
 * Clase que representa a un Administrador en el sistema de gestión de una tienda online.
 * Permite gestionar productos y usuarios en la tienda.
 */
public class Administrador extends Usuario {

    /**
     * Constructor de la clase Administrador.
     *
     * @param id       ID del administrador
     * @param username Nombre de usuario del administrador
     * @param password Contraseña del administrador
     */
    public Administrador(String id, String username, String password) {
        super(id, username, password);
    }

    /**
     * Método para mostrar información del administrador.
     */
    @Override
    public void displayInfo() {
        System.out.println("Administrador: " + username);
    }

    /**
     * Método para gestionar productos en la tienda.
     *
     * @param productos Lista de productos disponibles
     */
    public void gestionarProductos(List<Producto> productos) {
        Scanner scanner = new Scanner(System.in);
        boolean salir = false;

        while (!salir) {
            System.out.println("1. Agregar producto");
            System.out.println("2. Modificar producto");
            System.out.println("3. Eliminar producto");
            System.out.println("4. Volver al menú anterior");
            int opcion = scanner.nextInt();
            scanner.nextLine(); // Consumir la nueva línea

            switch (opcion) {
                case 1:
                    // Agregar producto
                    agregarProducto(productos, scanner);
                    break;
                case 2:
                    // Modificar producto
                    modificarProducto(productos, scanner);
                    break;
                case 3:
                    // Eliminar producto
                    eliminarProducto(productos, scanner);
                    break;
                case 4:
                    salir = true;
                    break;
                default:
                    System.out.println("Opción no válida.");
                    break;
            }
        }
    }

    /**
     * Método para agregar un nuevo producto a la tienda.
     *
     * @param productos Lista de productos disponibles
     * @param scanner   Scanner para leer la entrada del usuario
     */
    private void agregarProducto(List<Producto> productos, Scanner scanner) {
        System.out.println("Ingrese el ID del producto:");
        String idProducto = scanner.nextLine();
        System.out.println("Ingrese el nombre del producto:");
        String nombreProducto = scanner.nextLine();
        System.out.println("Ingrese el modelo del producto:");
        String modeloProducto = scanner.nextLine();
        System.out.println("Ingrese la descripción del producto:");
        String descripcionProducto = scanner.nextLine();
        System.out.println("Ingrese la disponibilidad del producto:");
        int disponibilidadProducto = scanner.nextInt();
        System.out.println("Ingrese el precio del producto:");
        float precioProducto = scanner.nextFloat();
        scanner.nextLine(); // Consumir la nueva línea

        Producto nuevoProducto = new Producto(idProducto, nombreProducto, modeloProducto,
                descripcionProducto, disponibilidadProducto, precioProducto);
        productos.add(nuevoProducto);
        System.out.println("Producto agregado correctamente.");
    }

    /**
     * Método para modificar un producto existente en la tienda.
     *
     * @param productos Lista de productos disponibles
     * @param scanner   Scanner para leer la entrada del usuario
     */
    private void modificarProducto(List<Producto> productos, Scanner scanner) {
        System.out.println("Ingrese el índice del producto a modificar:");
        int indiceModificar = scanner.nextInt();
        scanner.nextLine(); // Consumir la nueva línea

        if (indiceModificar >= 0 && indiceModificar < productos.size()) {
            Producto productoModificar = productos.get(indiceModificar);
            System.out.println("Ingrese el nuevo nombre del producto:");
            String nuevoNombreProducto = scanner.nextLine();
            productoModificar.setNombre(nuevoNombreProducto);
            System.out.println("Producto modificado correctamente.");
        } else {
            System.out.println("Índice de producto inválido.");
        }
    }

    /**
     * Método para eliminar un producto de la tienda.
     *
     * @param productos Lista de productos disponibles
     * @param scanner   Scanner para leer la entrada del usuario
     */
    private void eliminarProducto(List<Producto> productos, Scanner scanner) {
        System.out.println("Ingrese el índice del producto a eliminar:");
        int indiceEliminar = scanner.nextInt();
        scanner.nextLine(); // Consumir la nueva línea

        if (indiceEliminar >= 0 && indiceEliminar < productos.size()) {
            Producto productoEliminar = productos.remove(indiceEliminar);
            System.out.println("Producto eliminado correctamente: " + productoEliminar.getNombre());
        } else {
            System.out.println("Índice de producto inválido.");
        }
    }

    /**
     * Método para gestionar usuarios (vendedores y clientes) en la tienda.
     *
     * @param usuarios Lista de usuarios registrados en la tienda
     */
    public void gestionarUsuarios(List<Usuario> usuarios) {
        Scanner scanner = new Scanner(System.in);
        boolean salir = false;

        while (!salir) {
            System.out.println("1. Agregar vendedor");
            System.out.println("2. Agregar cliente");
            System.out.println("3. Modificar usuario");
            System.out.println("4. Eliminar usuario");
            System.out.println("5. Volver al menú anterior");
            int opcion = scanner.nextInt();
            scanner.nextLine(); // Consumir la nueva línea

            switch (opcion) {
                case 1:
                    // Agregar vendedor
                    agregarVendedor(usuarios, scanner);
                    break;
                case 2:
                    // Agregar cliente
                    agregarCliente(usuarios, scanner);  
                    break;
                case 3:
                    // Modificar usuario
                    modificarUsuario(usuarios, scanner);
                    break;
                case 4:
                    // Eliminar usuario
                    eliminarUsuario(usuarios, scanner);
                    break;
                case 5:
                    salir = true;
                    break;
                default:
                    System.out.println("Opción no válida.");
                    break;
            }
        }
    }

    /**
     * Método para agregar un nuevo vendedor a la tienda.
     *
     * @param usuarios Lista de usuarios registrados en la tienda
     * @param scanner  Scanner para leer la entrada del usuario
     */
    private void agregarVendedor(List<Usuario> usuarios, Scanner scanner) {
        System.out.println("Ingrese el ID de usuario del vendedor:");
        String idVendedor = scanner.nextLine();
        System.out.println("Ingrese el nombre de usuario del vendedor:");
        String nombreVendedor = scanner.nextLine();
        System.out.println("Ingrese la contraseña del vendedor:");
        String contrasenaVendedor = scanner.nextLine();

        Vendedor nuevoVendedor = new Vendedor(idVendedor, nombreVendedor, contrasenaVendedor);
        usuarios.add(nuevoVendedor);
        System.out.println("Vendedor agregado correctamente.");
    }

    /**
     * Método para agregar un nuevo cliente a la tienda.
     *
     * @param usuarios Lista de usuarios registrados en la tienda
     * @param scanner  Scanner para leer la entrada del usuario
     */
    private void agregarCliente(List<Usuario> usuarios, Scanner scanner) {
        System.out.println("Ingrese el ID de usuario del cliente:");
        String idCliente = scanner.nextLine();
        System.out.println("Ingrese el nombre de usuario del cliente:");
        String nombreCliente = scanner.nextLine();
        System.out.println("Ingrese la contraseña del cliente:");
        String contrasenaCliente = scanner.nextLine();
        System.out.println("Ingrese el nombre del cliente:");
        String nombre = scanner.nextLine();
        System.out.println("Ingrese la dirección del cliente:");
        String direccion = scanner.nextLine();
        System.out.println("Ingrese el email del cliente:");
        String email = scanner.nextLine();
        System.out.println("Ingrese el teléfono del cliente:");
        String telefono = scanner.nextLine();

        Cliente nuevoCliente = new Cliente(idCliente, nombreCliente, contrasenaCliente, nombre, direccion, email, telefono);
        usuarios.add(nuevoCliente);
        System.out.println("Cliente agregado correctamente.");
    }
    
    /**
     * Método para modificar un usuario existente en la tienda.
     *
     * @param usuarios Lista de usuarios registrados en la tienda
     * @param scanner  Scanner para leer la entrada del usuario
     */
    private void modificarUsuario(List<Usuario> usuarios, Scanner scanner) {
        System.out.println("Ingrese el índice del usuario a modificar:");
        int indiceModificar = scanner.nextInt();
        scanner.nextLine(); // Consumir la nueva línea

        if (indiceModificar >= 0 && indiceModificar < usuarios.size()) {
            Usuario usuarioModificar = usuarios.get(indiceModificar);
            if (usuarioModificar instanceof Vendedor) {
                System.out.println("Ingrese el nuevo nombre de usuario del vendedor:");
            } else if (usuarioModificar instanceof Cliente) {
                System.out.println("Ingrese el nuevo nombre de usuario del cliente:");
            }
            String nuevoNombreUsuario = scanner.nextLine();
            usuarioModificar.setUsuario(nuevoNombreUsuario);
            System.out.println("Usuario modificado correctamente.");
        } else {
            System.out.println("Índice de usuario inválido.");
        }

    }
    
    /**
     * Método para eliminar un usuario de la tienda.
     *
     * @param usuarios Lista de usuarios registrados en la tienda
     * @param scanner  Scanner para leer la entrada del usuario
     */
    public void eliminarUsuario(List<Usuario> usuarios, Scanner scanner) {
        System.out.println("Ingrese el índice del usuario a eliminar:");
        int indiceEliminar = scanner.nextInt();
        scanner.nextLine(); // Consumir la nueva línea

        if (indiceEliminar >= 0 && indiceEliminar < usuarios.size()) {
            Usuario usuarioEliminar = usuarios.remove(indiceEliminar);
            System.out.println("Usuario eliminado correctamente: " + usuarioEliminar.getUsuario());
        } else {
            System.out.println("Índice de usuario inválido.");
        }
    }
}
