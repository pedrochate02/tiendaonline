package tiendaonline2;

import java.util.ArrayList;
import java.util.List;

/**
 * Representa un cliente registrado en el sistema de la tienda online.
 * Extiende la clase abstracta Usuario e incluye información adicional
 * como nombre, dirección, correo electrónico, teléfono y pedidos realizados.
 */
class Cliente extends Usuario {
    private String nombre;
    private String direccion;
    private String email;
    private String telefono;
    private List<Pedido> pedidos;

    /**
     * Constructor para inicializar un objeto Cliente con todos los atributos necesarios.
     *
     * @param id        Identificador único del cliente
     * @param username  Nombre de usuario del cliente
     * @param password  Contraseña del cliente
     * @param nombre    Nombre completo del cliente
     * @param direccion Dirección de residencia del cliente
     * @param email     Correo electrónico del cliente
     * @param telefono  Número de teléfono del cliente
     */
    public Cliente(String id, String username, String password, String nombre, String direccion, String email, String telefono) {
        super(id, username, password);
        this.nombre = nombre;
        this.direccion = direccion;
        this.email = email;
        this.telefono = telefono;
            this.pedidos = new ArrayList<>();
    }

    /**
     * Obtiene el nombre completo del cliente.
     *
     * @return Nombre del cliente
     */
    public String getNombreCliente() {
        return nombre;
    }

    /**
     * Establece el nombre completo del cliente.
     *
     * @param nombre Nuevo nombre del cliente
     */
    public void setNombreCliente(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Obtiene la dirección de residencia del cliente.
     *
     * @return Dirección del cliente
     */
    public String getDireccionCliente() {
        return direccion;
    }

    /**
     * Establece la dirección de residencia del cliente.
     *
     * @param direccion Nueva dirección del cliente
     */
    public void setDireccionCliente(String direccion) {
        this.direccion = direccion;
    }

    /**
     * Obtiene el correo electrónico del cliente.
     *
     * @return Correo electrónico del cliente
     */
    public String getCorreoElectronicoCliente() {
        return email;
    }

    /**
     * Establece el correo electrónico del cliente.
     *
     * @param email Nuevo correo electrónico del cliente
     */
    public void setCorreoElectronicoCliente(String email) {
        this.email = email;
    }

    /**
     * Obtiene el número de teléfono del cliente.
     *
     * @return Teléfono del cliente
     */
    public String getTelefonoCliente() {
        return telefono;
    }

    /**
     * Establece el número de teléfono del cliente.
     *
     * @param telefono Nuevo número de teléfono del cliente
     */
    public void setTelefonoCliente(String telefono) {
        this.telefono = telefono;
    }

    /**
     * Obtiene el identificador único del cliente.
     *
     * @return Identificador único del cliente
     */
    public String getIdCliente() {
        return id;
    }

    /**
     * Establece el identificador único del cliente.
     *
     * @param id Nuevo identificador único del cliente
     */
    public void setIdCliente(String id) {
        this.id = id;
    }

    /**
     * Registra un nuevo pedido realizado por el cliente.
     *
     * @param pedido Pedido a ser registrado
     */
    public void realizarPedido(Pedido pedido) {
        pedidos.add(pedido);
    }

    /**
     * Consulta todos los pedidos realizados por el cliente.
     *
     * @return Lista de pedidos realizados por el cliente
     */
    public List<Pedido> consultarPedidos() {
        return pedidos;
    }

    /**
     * Muestra la información básica del cliente por consola.
     */
    @Override
    public void displayInfo() {
        System.out.println("Cliente: " + nombre);
    }
}
