package tiendaonline2;

import java.util.ArrayList;
import java.util.List;

/**
 * Clase que gestiona los datos predefinidos de administradores y vendedores.
 */
public class Datos {

    private List<Administrador> administradores;
    private List<Vendedor> vendedores;
    private List<Cliente> clientes;

    /**
     * Constructor de la clase Datos. Inicializa las listas de administradores y vendedores.
     */
    public Datos() {
        administradores = new ArrayList<>();
        vendedores = new ArrayList<>();
        clientes = new ArrayList<>();
        inicializarAdministradores();
        inicializarVendedores();
    }

    /**
     * Inicializa la lista de administradores con datos predefinidos.
     */
    public void inicializarAdministradores() {
        administradores.add(new Administrador("1", "jrfretes", "fretes123"));
    }

    /**
     * Inicializa la lista de vendedores con datos predefinidos.
     */
    public void inicializarVendedores() {
        vendedores.add(new Vendedor("1", "Damian", "dami123"));
    }
    
    /**
     * Inicializa la lista de vendedores con datos predefinidos.
     */
    public void inicializarClientes() {
        clientes.add(new Cliente("1", "pedro", "pedro123","p1edroSalazar","Av Cabildo 123","pedro@utn.com","12345678"));
    }

    /**
     * Obtiene la lista de administradores.
     * @return Lista de administradores.
     */
    public List<Administrador> obtenerAdministradores() {
        return administradores;
    }

    /**
     * Obtiene la lista de vendedores.
     * @return Lista de vendedores.
     */
    public List<Vendedor> obtenerVendedores() {
        return vendedores;
    }
    
    /**
     * Obtiene la lista de clientes.
     * @return Lista de clientes.
     */
    public List<Cliente> obtenerClientes(){
        return clientes;
    }
}
