package tiendaonline2;

import java.util.List;
import java.util.Scanner;

/**
 * Clase que contiene métodos estáticos para mostrar menús interactivos
 * según el tipo de usuario.
 */
public class Menu {
    
    /**
     * Muestra el menú para clientes.
     * @param clienteUsuario Cliente que accede al menú.
     * @param scanner Scanner para entrada de datos.
     */
    public static void mostrarMenuCliente(Cliente clienteUsuario, Scanner scanner) {
        boolean salir = false;

        while (!salir) {
            System.out.println("1. Consultar pedidos");
            System.out.println("2. Salir");
            int opcion = scanner.nextInt();
            scanner.nextLine(); // Consumir la nueva línea

            switch (opcion) {
                case 1:
                    clienteUsuario.consultarPedidos();
                    break;
                case 2:
                    salir = true;
                    break;
                default:
                    System.out.println("Opción no válida.");
                    break;
            }
        }
    }
    
    /**
     * Muestra el menú para vendedores.
     * @param representante Vendedor que accede al menú.
     * @param pedidos Lista de pedidos disponibles.
     * @param usuarios Lista de clientes disponibles.
     * @param scanner Scanner para entrada de datos.
     */
    public static void mostrarMenuVendedor(Vendedor representante,List<Pedido> pedidos, List<Cliente> usuarios, Scanner scanner) {
        boolean salir = false;

        while (!salir) {
            System.out.println("1. Gestionar pedidos");
            System.out.println("2. Gestionar clientes");
            System.out.println("3. Salir");
            int opcion = scanner.nextInt();
            scanner.nextLine(); // Consumir la nueva línea

            switch (opcion) {
                case 1:
                    representante.gestionarPedidos(pedidos);
                    break;
                case 2:
                    representante.gestionarClientes(usuarios);
                    break;
                case 3:
                    salir = true;
                    break;
                default:
                    System.out.println("Opción no válida.");
                    break;
            }
        }
    }
    
    /**
     * Muestra el menú para administradores.
     * @param administrador Administrador que accede al menú.
     * @param productos Lista de productos disponibles.
     * @param usuarios Lista de usuarios disponibles.
     * @param scanner Scanner para entrada de datos.
     */
    public static void mostrarMenuAdministrador(Administrador administrador, List<Producto> productos, List<Usuario> usuarios,Scanner scanner) {
        boolean salir = false;

        while (!salir) {
            System.out.println("1. Gestionar productos");
            System.out.println("2. Gestionar usuarios");
            System.out.println("3. Salir");
            int opcion = scanner.nextInt();
            scanner.nextLine(); // Consumir la nueva línea

            switch (opcion) {
                case 1:
                    administrador.gestionarProductos(productos);
                    break;
                case 2:
                    administrador.gestionarUsuarios(usuarios);
                    break;
                case 3:
                    salir = true;
                    break;
                default:
                    System.out.println("Opción no válida.");
                    break;
            }
        }
    }

}
