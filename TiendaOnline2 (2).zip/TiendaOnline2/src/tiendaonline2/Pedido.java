package tiendaonline2;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Clase que representa un pedido realizado por un cliente.
 */
public class Pedido {
    private String id;
    private Cliente cliente;
    private Date fechaHora;
    private List<Producto> productos;
    private List<Integer> cantidades;
    private boolean enviado;
    private boolean entregado;

    /**
     * Constructor para inicializar un pedido con todos sus atributos.
     * 
     * @param id         ID único del pedido
     * @param cliente    Cliente que realiza el pedido
     * @param fechaHora  Fecha y hora en que se realiza el pedido
     */
    public Pedido(String id, Cliente cliente, Date fechaHora) {
        this.id = id;
        this.cliente = cliente;
        this.fechaHora = fechaHora;
        this.productos = new ArrayList<>();
        this.cantidades = new ArrayList<>();
        this.enviado = false;
        this.entregado = false;
    }

    /**
     * Agrega un producto al pedido con la cantidad especificada.
     * 
     * @param producto  Producto a agregar al pedido
     * @param cantidad  Cantidad del producto a agregar
     */
    public void agregarProducto(Producto producto, int cantidad) {
        productos.add(producto);
        cantidades.add(cantidad);
    }

    /**
     * Marca el pedido como enviado.
     */
    public void marcarEnviado() {
        this.enviado = true;
    }

    /**
     * Marca el pedido como entregado.
     */
    public void marcarEntregado() {
        this.entregado = true;
    }

    /**
     * Obtiene el ID único del pedido.
     * 
     * @return ID del pedido
     */
    public String getId() {
        return id;
    }

    /**
     * Obtiene el cliente que realizó el pedido.
     * 
     * @return Cliente que realizó el pedido
     */
    public Cliente getCliente() {
        return cliente;
    }

    /**
     * Obtiene la fecha y hora en que se realizó el pedido.
     * 
     * @return Fecha y hora del pedido
     */
    public Date getFechaHora() {
        return fechaHora;
    }

    /**
     * Obtiene la lista de productos incluidos en el pedido.
     * 
     * @return Lista de productos del pedido
     */
    public List<Producto> getProductos() {
        return productos;
    }

    /**
     * Obtiene la lista de cantidades de cada producto en el pedido.
     * 
     * @return Lista de cantidades de productos del pedido
     */
    public List<Integer> getCantidades() {
        return cantidades;
    }

    /**
     * Verifica si el pedido ha sido enviado.
     * 
     * @return true si el pedido ha sido enviado, false en caso contrario
     */
    public boolean isEnviado() {
        return enviado;
    }

    /**
     * Verifica si el pedido ha sido entregado.
     * 
     * @return true si el pedido ha sido entregado, false en caso contrario
     */
    public boolean isEntregado() {
        return entregado;
    }

    /**
     * Representación textual del objeto Pedido.
     */
    @Override
    public String toString() {
        return "Pedido{" +
                "id='" + id + '\'' +
                ", cliente=" + cliente.getNombreCliente() +
                ", fechaHora=" + fechaHora +
                ", productos=" + productos +
                ", cantidades=" + cantidades +
                ", enviado=" + enviado +
                ", entregado=" + entregado +
                '}';
    }
}
