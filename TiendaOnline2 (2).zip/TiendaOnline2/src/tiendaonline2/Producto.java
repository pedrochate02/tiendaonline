package tiendaonline2;

/**
 * Clase que representa un producto en la tienda online.
 */
public class Producto {
    private String id;
    private String nombre;
    private String modelo;
    private String descripcion;
    private int disponibilidad;
    private float precio;

    /**
     * Constructor para inicializar un producto con todos sus atributos.
     * 
     * @param id             ID único del producto
     * @param nombre         Nombre del producto
     * @param modelo         Modelo del producto
     * @param descripcion    Descripción del producto
     * @param disponibilidad Cantidad disponible del producto
     * @param precio         Precio del producto
     */
    public Producto(String id, String nombre, String modelo, String descripcion, int disponibilidad, float precio) {
        this.id = id;
        this.nombre = nombre;
        this.modelo = modelo;
        this.descripcion = descripcion;
        this.disponibilidad = disponibilidad;
        this.precio = precio;
    }

    /**
     * Obtiene la disponibilidad actual del producto.
     * 
     * @return Cantidad disponible del producto
     */
    public int getDisponibilidad() {
        return disponibilidad;
    }

    /**
     * Actualiza la disponibilidad del producto sumando o restando una cantidad específica.
     * 
     * @param cantidad Cantidad a sumar (si es positiva) o restar (si es negativa)
     */
    public void actualizarDisponibilidad(int cantidad) {
        this.disponibilidad += cantidad;
    }

    /**
     * Obtiene el nombre del producto.
     * 
     * @return Nombre del producto
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Establece un nuevo nombre para el producto.
     * 
     * @param nombre Nuevo nombre del producto
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Obtiene el modelo del producto.
     * 
     * @return Modelo del producto
     */
    public String getModelo() {
        return modelo;
    }

    /**
     * Establece un nuevo modelo para el producto.
     * 
     * @param modelo Nuevo modelo del producto
     */
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    /**
     * Obtiene la descripción del producto.
     * 
     * @return Descripción del producto
     */
    public String getDescripcion() {
        return descripcion;
    }

    /**
     * Establece una nueva descripción para el producto.
     * 
     * @param descripcion Nueva descripción del producto
     */
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    /**
     * Obtiene el precio del producto.
     * 
     * @return Precio del producto
     */
    public float getPrecio() {
        return precio;
    }

    /**
     * Establece un nuevo precio para el producto.
     * 
     * @param precio Nuevo precio del producto
     */
    public void setPrecio(float precio) {
        this.precio = precio;
    }
}
