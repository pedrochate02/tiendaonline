package tiendaonline2;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Clase principal que gestiona el sistema de pedidos de una tienda online.
 * Permite la autenticación de usuarios y redirige a las funciones correspondientes
 * según el tipo de usuario autenticado (cliente, vendedor, administrador).
 */
public class SistemaGestionPedidos {
    private List<Cliente> clientes;
    private List<Producto> productos;
    private List<Pedido> pedidos;
    private List<Usuario> usuarios;
    private Datos datos;

    /**
     * Constructor para inicializar las listas de clientes, productos, pedidos y usuarios.
     * Aquí se podría añadir la inicialización de todos los datos necesarios.
     */
    public SistemaGestionPedidos() {
        clientes = new ArrayList<>();
        productos = new ArrayList<>();
        pedidos = new ArrayList<>();
        usuarios = new ArrayList<>();
        datos = new Datos();
        datos.inicializarAdministradores();
        datos.inicializarVendedores();
        datos.inicializarClientes();
       
    }

    /**
     * Método para iniciar el sistema de gestión de pedidos.
     * Crea una instancia del sistema y llama al método iniciar().
     *
     * @param args Argumentos de la línea de comandos (no utilizado).
     */
    public static void main(String[] args) {
        SistemaGestionPedidos sistema = new SistemaGestionPedidos();
        sistema.iniciar();
    }

    /**
     * Método para iniciar la interfaz de usuario del sistema.
     * Permite al usuario iniciar sesión o salir del sistema.
     */
    public void iniciar() {
        Scanner scanner = new Scanner(System.in);
        boolean salir = false;

        while (!salir) {
            System.out.println("    Bienvenido al Sistema de Gestion de Ventas Online");
            System.out.println(" ");
            System.out.println("Seleccione el tipo de usuario:");
            System.out.println("1. Cliente");
            System.out.println("2. Vendedor");
            System.out.println("3. Administrador");
            System.out.println("4. Salir");
            System.out.println(" ");
            System.out.println("Ingrese una opcion: ");
            int opcion = scanner.nextInt();
            scanner.nextLine(); 

            switch (opcion) {
                case 1:
                    iniciarSesionCliente(scanner);
                    break;
                case 2:
                    iniciarSesionVendedor(scanner);
                    break;
                case 3:
                    iniciarSesionAdministrador(scanner);
                    break;
                case 4:
                    salir = true;
                    break;
                default:
                    System.out.println("Opción no válida.");
                    break;
            }
        }
    }

  /**
 * Inicia sesión para un cliente en el sistema de gestión de pedidos.
 * Verifica las credenciales proporcionadas y redirige al menú de cliente si las credenciales son correctas.
 * Imprime un mensaje de error si las credenciales son incorrectas.
 *
 * @param scanner Scanner para leer la entrada del usuario.
 */
  public void iniciarSesionCliente(Scanner scanner) {
    System.out.println("Nombre de usuario:");
    String nombreUsuario = scanner.nextLine();
    System.out.println("Contraseña:");
    String contrasena = scanner.nextLine();

    List<Cliente> clientes = datos.obtenerClientes(); // Asegúrate de que este método devuelva datos válidos

    for (Cliente cliente : clientes) {
        if (cliente.getUsuario().equals(nombreUsuario) && cliente.getContrasena().equals(contrasena)) {
            System.out.println("Bienvenido, " + cliente.getUsuario());
            Menu.mostrarMenuCliente(cliente, scanner); // Llama al menú para el cliente
            return;
        }
    }

    System.out.println("Usuario o contraseña incorrectos.");
}

   /**
 * Inicia sesión para un vendedor en el sistema de gestión de pedidos.
 * Verifica las credenciales proporcionadas y redirige al menú de vendedor si las credenciales son correctas.
 * Imprime un mensaje de error si las credenciales son incorrectas.
 *
 * @param scanner Scanner para leer la entrada del usuario.
 */
    public void iniciarSesionVendedor(Scanner scanner) {
    System.out.println("Nombre de usuario:");
    String nombreUsuario = scanner.nextLine();
    System.out.println("Contraseña:");
    String contrasena = scanner.nextLine();

    List<Vendedor> vendedores = datos.obtenerVendedores(); // Asegúrate de que este método devuelva datos válidos

    for (Vendedor vendedor : vendedores) {
        if (vendedor.getUsuario().equals(nombreUsuario) && vendedor.getContrasena().equals(contrasena)) {
            System.out.println("Bienvenido, " + vendedor.getUsuario());
            Menu.mostrarMenuVendedor(vendedor, pedidos, clientes, scanner); // Llama al menú para el vendedor
            return;
        }
    }

    System.out.println("Usuario o contraseña incorrectos.");
}
    

  /**
 * Inicia sesión para un administrador en el sistema de gestión de pedidos.
 * Verifica las credenciales proporcionadas y redirige al menú de administrador si las credenciales son correctas.
 * Imprime un mensaje de error si las credenciales son incorrectas.
 *
 * @param scanner Scanner para leer la entrada del usuario.
 */
    private void iniciarSesionAdministrador(Scanner scanner) {
        System.out.println("Inicio de sesión como administrador");
        System.out.println("Nombre de usuario:");
        String nombreUsuario = scanner.nextLine();
        System.out.println("Contraseña:");
        String contrasena = scanner.nextLine();

        List<Administrador> administradores = datos.obtenerAdministradores(); // Asegúrate de que este método esté devolviendo datos válidos

    for (Administrador admin : administradores) {
        if (admin.getUsuario().equals(nombreUsuario) && admin.getContrasena().equals(contrasena)) {
            System.out.println("Bienvenido, " + admin.getUsuario());
            Menu.mostrarMenuAdministrador(admin, productos, usuarios, scanner); // Llama al menú para el administrador
            return;
        }
    }

    System.out.println("Usuario o contraseña incorrectos.");
    }


}
