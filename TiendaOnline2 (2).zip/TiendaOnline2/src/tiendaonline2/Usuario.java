package tiendaonline2;

/**
 * Clase abstracta que representa un usuario genérico en el sistema.
 */
abstract class Usuario {
    protected String id;
    protected String username;
    protected String password;

    /**
     * Constructor para inicializar un usuario con ID, nombre de usuario y contraseña.
     * 
     * @param id       ID del usuario
     * @param username Nombre de usuario
     * @param password Contraseña del usuario
     */
    public Usuario(String id, String username, String password) {
        this.id = id;
        this.username = username;
        this.password = password;
    }

    /**
     * Método para mostrar información básica del usuario.
     */
    public void displayInfo() {
        System.out.println("Usuario: " + username);
    }

    /**
     * Obtiene el nombre de usuario.
     * 
     * @return Nombre de usuario
     */
    public String getUsuario() {
        return username;
    }

    /**
     * Establece el nombre de usuario.
     * 
     * @param usuario Nuevo nombre de usuario
     */
    public void setUsuario(String usuario) {
        this.username = usuario;
    }

    /**
     * Obtiene la contraseña del usuario.
     * 
     * @return Contraseña del usuario
     */
    public String getContrasena() {
        return password;
    }

    /**
     * Establece la contraseña del usuario.
     * 
     * @param contrasena Nueva contraseña del usuario
     */
    public void setContrasena(String contrasena) {
        this.password = contrasena;
    }
}