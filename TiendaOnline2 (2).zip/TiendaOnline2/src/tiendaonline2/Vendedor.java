package tiendaonline2;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

/**
 * Clase que representa a un vendedor en el sistema de gestión de pedidos.
 * Extiende de la clase Usuario e implementa métodos específicos para gestionar pedidos y clientes.
 */
class Vendedor extends Usuario {

    /**
     * Constructor de la clase Vendedor.
     *
     * @param id       ID del vendedor.
     * @param username Nombre de usuario del vendedor.
     * @param password Contraseña del vendedor.
     */
    public Vendedor(String id, String username, String password) {
        super(id, username, password);
    }

    /**
     * Método para mostrar la información del vendedor.
     * Override del método displayInfo de la clase Usuario.
     */
    @Override
    public void displayInfo() {
        System.out.println("Representante de ventas: " + username);
    }

    /**
     * Método para obtener el ID del vendedor.
     *
     * @return ID del vendedor.
     */
    public String getId() {
        return id;
    }

    /**
     * Método para obtener el nombre del vendedor.
     *
     * @return Nombre de usuario del vendedor.
     */
    public String getNombreVendedor() {
        return username;
    }

    /**
     * Método para obtener la contraseña del vendedor.
     *
     * @return Contraseña del vendedor.
     */
    public String getContrasenaVendedor() {
        return password;
    }

    /**
     * Método para gestionar los pedidos del vendedor.
     *
     * @param pedidos Lista de pedidos a gestionar.
     */
    void gestionarPedidos(List<Pedido> pedidos) {
        Scanner scanner = new Scanner(System.in);
        boolean salir = false;

        while (!salir) {
            System.out.println("1. Listar pedidos");
            System.out.println("2. Modificar pedido");
            System.out.println("3. Eliminar pedido");
            System.out.println("4. Agregar pedido");
            System.out.println("5. Volver al menú anterior");
            int opcion = scanner.nextInt();
            scanner.nextLine(); // Consumir la nueva línea

            switch (opcion) {
                case 1:
                    listarPedidos(pedidos);
                    break;
                case 2:
                    modificarPedido(pedidos);
                    break;
                case 3:
                    eliminarPedido(pedidos);
                    break;
                case 4:
                    agregarPedido(pedidos);
                    break;
                case 5:
                    salir = true;
                    break;
                default:
                    System.out.println("Opción no válida.");
                    break;
            }
        }
    }

    /**
     * Método privado para listar los pedidos.
     *
     * @param pedidos Lista de pedidos a listar.
     */
    private void listarPedidos(List<Pedido> pedidos) {
        System.out.println("Listando pedidos:");
        for (Pedido pedido : pedidos) {
            System.out.println(pedido.toString());
        }
    }

    /**
     * Método privado para modificar un pedido.
     *
     * @param pedidos Lista de pedidos donde se modificará el pedido.
     */
   private void modificarPedido(List<Pedido> pedidos) {
    Scanner scanner = new Scanner(System.in);
    System.out.println("Ingrese el índice del pedido a modificar:");
    int indiceModificar = 0;
    try {
        indiceModificar = scanner.nextInt();
    } catch (InputMismatchException e) {
        System.out.println("Entrada no válida. Debe ingresar un número.");
        scanner.nextLine(); // Limpiar el buffer del scanner
        return;
    }
    scanner.nextLine(); // Consumir la nueva línea después de nextInt()

    if (indiceModificar >= 0 && indiceModificar < pedidos.size()) {
        // Aquí implementa la lógica para modificar el pedido
        System.out.println("Pedido modificado correctamente.");
    } else {
        System.out.println("Índice de pedido inválido.");
    }
}


    /**
     * Método privado para eliminar un pedido.
     *
     * @param pedidos Lista de pedidos donde se eliminará el pedido.
     */
    private void eliminarPedido(List<Pedido> pedidos) {
    Scanner scanner = new Scanner(System.in);
    System.out.println("Ingrese el índice del pedido a eliminar:");
    int indiceEliminar = 0;
    try {
        indiceEliminar = scanner.nextInt();
        scanner.nextLine(); // Consumir la nueva línea
    } catch (InputMismatchException e) {
        System.out.println("Entrada no válida. Debe ingresar un número.");
        scanner.nextLine(); // Limpiar el buffer del scanner
        return;
    }
    if (indiceEliminar >= 0 && indiceEliminar < pedidos.size()) {
        Pedido pedidoEliminado = pedidos.remove(indiceEliminar);
        System.out.println("Pedido eliminado correctamente: " + pedidoEliminado.toString());
    } else {
        System.out.println("Índice de pedido inválido.");
    }
}

    /**
     * Método privado para agregar un pedido.
     *
     * @param pedidos Lista de pedidos donde se agregará el nuevo pedido.
     */
    private void agregarPedido(List<Pedido> pedidos) {
        // Implementar lógica para agregar un nuevo pedido
        System.out.println("Pedido agregado correctamente.");
    }

    /**
     * Método para gestionar los clientes del vendedor.
     *
     * @param clientes Lista de clientes a gestionar.
     */
    void gestionarClientes(List<Cliente> clientes) {
        Scanner scanner = new Scanner(System.in);
        boolean salir = false;

        while (!salir) {
            System.out.println("1. Listar clientes");
            System.out.println("2. Modificar cliente");
            System.out.println("3. Eliminar cliente");
            System.out.println("4. Agregar cliente");
            System.out.println("5. Volver al menú anterior");
            int opcion = scanner.nextInt();
            scanner.nextLine(); // Consumir la nueva línea

            switch (opcion) {
                case 1:
                    listarClientes(clientes);
                    break;
                case 2:
                    modificarCliente(clientes);
                    break;
                case 3:
                    eliminarCliente(clientes);
                    break;
                case 4:
                    agregarCliente(clientes);
                    break;
                case 5:
                    salir = true;
                    break;
                default:
                    System.out.println("Opción no válida.");
                    break;
            }
        }
    }

    /**
     * Método privado para listar los clientes.
     *
     * @param clientes Lista de clientes a listar.
     */
    private void listarClientes(List<Cliente> clientes) {
        System.out.println("Listando clientes:");
        for (Cliente cliente : clientes) {
            System.out.println(cliente.toString());
        }
    }

    /**
     * Método privado para modificar un cliente.
     *
     * @param clientes Lista de clientes donde se modificará el cliente.
     */
   private void modificarCliente(List<Cliente> clientes) {
    Scanner scanner = new Scanner(System.in);
    System.out.println("Ingrese el índice del cliente a modificar:");
    int indiceModificar = 0;
    try {
        indiceModificar = scanner.nextInt();
    } catch (InputMismatchException e) {
        System.out.println("Entrada no válida. Debe ingresar un número.");
        scanner.nextLine(); // Limpiar el buffer del scanner
        return;
    }
    scanner.nextLine(); // Consumir la nueva línea después de nextInt()

    if (indiceModificar >= 0 && indiceModificar < clientes.size()) {
        // Aquí implementa la lógica para modificar el cliente
        Cliente clienteModificar = clientes.get(indiceModificar);
        // Por ejemplo, podrías pedir nuevos datos al usuario y actualizar el cliente
        System.out.println("Cliente modificado correctamente.");
    } else {
        System.out.println("Índice de cliente inválido.");
    }
}


    /**
     * Método privado para eliminar un cliente.
     *
     * @param clientes Lista de clientes donde se eliminará el cliente.
     */
   private void eliminarCliente(List<Cliente> clientes) {
    Scanner scanner = new Scanner(System.in);

    System.out.println("Ingrese el índice del cliente a eliminar:");
    int indiceEliminar = 0;
    try {
        indiceEliminar = scanner.nextInt();
        scanner.nextLine(); // Consumir la nueva línea después de nextInt()
    } catch (InputMismatchException e) {
        System.out.println("Entrada no válida. Debe ingresar un número.");
        scanner.nextLine(); // Consumir la nueva línea en caso de error
        return;
    }

    if (indiceEliminar >= 0 && indiceEliminar < clientes.size()) {
        Cliente clienteEliminado = clientes.remove(indiceEliminar);
        System.out.println("Cliente eliminado correctamente: " + clienteEliminado.toString());
    } else {
        System.out.println("Índice de cliente inválido.");
    }
}


    /**
     * Método privado para agregar un cliente.
     *
     * @param clientes Lista de clientes donde se agregará el nuevo cliente.
     */
    private void agregarCliente(List<Cliente> clientes) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese el ID del cliente:");
        String idCliente = scanner.nextLine();
        System.out.println("Ingrese el nombre de usuario del cliente:");
        String usuarioCliente = scanner.nextLine();
        System.out.println("Ingrese la contraseña del cliente:");
        String contrasenaCliente = scanner.nextLine();
        System.out.println("Ingrese el nombre completo del cliente:");
        String nombreCliente = scanner.nextLine();
        System.out.println("Ingrese la direccion del cliente:");
        String direccionCliente = scanner.nextLine();
        System.out.println("Ingrese email del cliente:");
        String emailCliente = scanner.nextLine();
        System.out.println("Ingrese telefono del cliente:");
        String telefonoCliente = scanner.nextLine();
        // Aquí puedes agregar lógica para ingresar más detalles del cliente si es necesario
        Cliente nuevoCliente = new Cliente(idCliente, usuarioCliente, contrasenaCliente, nombreCliente, direccionCliente, emailCliente, telefonoCliente);
        clientes.add(nuevoCliente);
        System.out.println("Cliente agregado correctamente.");
    }
}
